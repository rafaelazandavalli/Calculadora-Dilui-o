import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Trash2, Plus, Calculator, TrendingUp } from 'lucide-react'
import './App.css'

function App() {
  const [socios, setSocios] = useState([
    { id: 1, nome: '', percentual: '' }
  ])
  const [valuationPreMoney, setValuationPreMoney] = useState('')
  const [valorAporte, setValorAporte] = useState('')
  const [resultados, setResultados] = useState(null)

  const adicionarSocio = () => {
    const novoId = Math.max(...socios.map(s => s.id)) + 1
    setSocios([...socios, { id: novoId, nome: '', percentual: '' }])
  }

  const removerSocio = (id) => {
    if (socios.length > 1) {
      setSocios(socios.filter(s => s.id !== id))
    }
  }

  const atualizarSocio = (id, campo, valor) => {
    setSocios(socios.map(s => 
      s.id === id ? { ...s, [campo]: valor } : s
    ))
  }

  const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor)
  }

  const formatarPercentual = (valor) => {
    return `${valor.toFixed(2)}%`
  }

  const calcularDiluicao = () => {
    // Validações
    const sociosValidos = socios.filter(s => s.nome.trim() && s.percentual.trim())
    if (sociosValidos.length === 0) {
      alert('Adicione pelo menos um sócio com nome e percentual')
      return
    }

    if (!valuationPreMoney || !valorAporte) {
      alert('Preencha o valuation pré-money e o valor do aporte')
      return
    }

    const preMoneyValue = parseFloat(valuationPreMoney)
    const aporteValue = parseFloat(valorAporte)

    if (preMoneyValue <= 0 || aporteValue <= 0) {
      alert('Os valores devem ser maiores que zero')
      return
    }

    // Preparar dados dos sócios
    const sociosParaCalculo = sociosValidos.map(s => ({
      nome: s.nome,
      percentual: parseFloat(s.percentual || 0)
    }))

    // Verificar se os percentuais somam 100%, se não, normalizar
    const totalPercentual = sociosParaCalculo.reduce((total, s) => total + s.percentual, 0)
    
    if (Math.abs(totalPercentual - 100) > 0.01) {
      // Normalizar os percentuais
      const fatorNormalizacao = 100 / totalPercentual
      sociosParaCalculo.forEach(socio => {
        socio.percentual = socio.percentual * fatorNormalizacao
      })
    }

    // Cálculos de diluição
    const valuationPosMoney = preMoneyValue + aporteValue
    const percentualNovoInvestidor = (aporteValue / valuationPosMoney) * 100
    
    const novosPercentuais = sociosParaCalculo.map(socio => ({
      nome: socio.nome,
      percentualOriginal: socio.percentual,
      novoPercentual: socio.percentual * (preMoneyValue / valuationPosMoney),
      diluicao: socio.percentual - (socio.percentual * (preMoneyValue / valuationPosMoney))
    }))

    setResultados({
      valuationPreMoney: preMoneyValue,
      valorAporte: aporteValue,
      valuationPosMoney,
      percentualNovoInvestidor,
      percentualDiluicaoTotal: percentualNovoInvestidor,
      novosPercentuais,
      foiNormalizado: Math.abs(totalPercentual - 100) > 0.01,
      totalOriginal: totalPercentual
    })
  }

  const limparFormulario = () => {
    setSocios([{ id: 1, nome: '', percentual: '' }])
    setValuationPreMoney('')
    setValorAporte('')
    setResultados(null)
  }

  const carregarExemplo = () => {
    setSocios([
      { id: 1, nome: 'João', percentual: '60' },
      { id: 2, nome: 'Maria', percentual: '40' }
    ])
    setValuationPreMoney('1000000')
    setValorAporte('250000')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
            <TrendingUp className="h-10 w-10 text-blue-600" />
            Calculadora de Diluição Societária
          </h1>
          <p className="text-lg text-gray-600">
            Calcule a diluição societária da sua startup com precisão
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Formulário de Entrada */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Sócios Atuais
                </CardTitle>
                <CardDescription>
                  Adicione os sócios atuais e seus percentuais de participação
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {socios.map((socio, index) => (
                  <div key={socio.id} className="flex gap-3 items-end">
                    <div className="flex-1">
                      <Label htmlFor={`nome-${socio.id}`}>Nome do Sócio</Label>
                      <Input
                        id={`nome-${socio.id}`}
                        placeholder="Ex: João Silva"
                        value={socio.nome}
                        onChange={(e) => atualizarSocio(socio.id, 'nome', e.target.value)}
                      />
                    </div>
                    <div className="w-32">
                      <Label htmlFor={`percentual-${socio.id}`}>Percentual (%)</Label>
                      <Input
                        id={`percentual-${socio.id}`}
                        type="number"
                        placeholder="50"
                        min="0"
                        max="100"
                        step="0.01"
                        value={socio.percentual}
                        onChange={(e) => atualizarSocio(socio.id, 'percentual', e.target.value)}
                      />
                    </div>
                    {socios.length > 1 && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => removerSocio(socio.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  variant="outline"
                  onClick={adicionarSocio}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Sócio
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Dados Financeiros
                </CardTitle>
                <CardDescription>
                  Informe o valuation pré-money e o valor do aporte
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="valuation-pre">Valuation Pré-Money (R$)</Label>
                  <Input
                    id="valuation-pre"
                    type="number"
                    placeholder="1000000"
                    min="0"
                    step="0.01"
                    value={valuationPreMoney}
                    onChange={(e) => setValuationPreMoney(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="valor-aporte">Valor do Aporte (R$)</Label>
                  <Input
                    id="valor-aporte"
                    type="number"
                    placeholder="250000"
                    min="0"
                    step="0.01"
                    value={valorAporte}
                    onChange={(e) => setValorAporte(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button onClick={calcularDiluicao} className="flex-1">
                <Calculator className="h-4 w-4 mr-2" />
                Calcular Diluição
              </Button>
              <Button variant="outline" onClick={carregarExemplo}>
                Exemplo
              </Button>
              <Button variant="outline" onClick={limparFormulario}>
                Limpar
              </Button>
            </div>
          </div>

          {/* Resultados */}
          <div>
            {resultados ? (
              <div className="space-y-6">
                {resultados.foiNormalizado && (
                  <Card className="border-yellow-200 bg-yellow-50">
                    <CardHeader>
                      <CardTitle className="text-yellow-800 text-sm">⚠️ Normalização Aplicada</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-yellow-700">
                        Os percentuais dos sócios somavam {resultados.totalOriginal.toFixed(2)}% e foram 
                        normalizados para 100% antes do cálculo da diluição.
                      </p>
                    </CardContent>
                  </Card>
                )}

                <Card>
                  <CardHeader>
                    <CardTitle className="text-green-700">Resumo Financeiro</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Valuation Pré-Money:</span>
                      <span className="font-bold text-blue-700">
                        {formatarMoeda(resultados.valuationPreMoney)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                      <span className="font-medium">Valor do Aporte:</span>
                      <span className="font-bold text-green-700">
                        {formatarMoeda(resultados.valorAporte)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                      <span className="font-medium">Valuation Pós-Money:</span>
                      <span className="font-bold text-purple-700">
                        {formatarMoeda(resultados.valuationPosMoney)}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-orange-700">Diluição</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                      <span className="font-medium">Percentual do Novo Investidor:</span>
                      <span className="font-bold text-orange-700">
                        {formatarPercentual(resultados.percentualNovoInvestidor)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                      <span className="font-medium">Diluição Total:</span>
                      <span className="font-bold text-red-700">
                        {formatarPercentual(resultados.percentualDiluicaoTotal)}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-700">Novos Percentuais dos Sócios</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {resultados.novosPercentuais.map((socio, index) => (
                        <div key={index} className="p-4 border rounded-lg bg-gray-50">
                          <div className="font-semibold text-gray-900 mb-2">{socio.nome}</div>
                          <div className="grid grid-cols-3 gap-2 text-sm">
                            <div>
                              <span className="text-gray-600">Original:</span>
                              <div className="font-medium text-blue-600">
                                {formatarPercentual(socio.percentualOriginal)}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-600">Novo:</span>
                              <div className="font-medium text-green-600">
                                {formatarPercentual(socio.novoPercentual)}
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-600">Diluição:</span>
                              <div className="font-medium text-red-600">
                                -{formatarPercentual(socio.diluicao)}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-700 text-sm">Verificação</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-gray-600">
                      <div className="flex justify-between">
                        <span>Soma dos sócios:</span>
                        <span>{formatarPercentual(resultados.novosPercentuais.reduce((sum, s) => sum + s.novoPercentual, 0))}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Investidor:</span>
                        <span>{formatarPercentual(resultados.percentualNovoInvestidor)}</span>
                      </div>
                      <div className="flex justify-between font-medium border-t pt-2 mt-2">
                        <span>Total:</span>
                        <span>{formatarPercentual(resultados.novosPercentuais.reduce((sum, s) => sum + s.novoPercentual, 0) + resultados.percentualNovoInvestidor)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <Calculator className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">
                    Aguardando Cálculo
                  </h3>
                  <p className="text-gray-500">
                    Preencha os dados dos sócios e informações financeiras para calcular a diluição
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default App

